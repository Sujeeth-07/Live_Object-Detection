pip install -r requirements.txt
wget -O yolov3.weights https://pjreddie.com/media/files/yolov3.weights